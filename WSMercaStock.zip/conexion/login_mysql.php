﻿<?php
/**
 * Provee las constantes para conectarse a la base de datos
 * Mysql.
 */
define("NOMBRE_HOST", "50.62.209.162");// Nombre del host
define("BASE_DE_DATOS", "mercatto_mstock"); // Nombre de la base de controladores
define("USUARIO", "mercattoadmin"); // Nombre del usuario
define("CONTRASENA", "Sy5@dm1n1*"); // Constraseña
